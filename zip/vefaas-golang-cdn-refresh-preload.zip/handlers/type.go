package handlers

type TaskKind = string

const (
	Refresh TaskKind = "refresh"
	Preload TaskKind = "preload"
)

type TaskType = string

const (
	File  TaskType = "file"
	Dir   TaskType = "dir"
	Regex TaskType = "regex"
)

// see https://www.volcengine.com/docs/6454/70438
type ContentTask struct {
	TaskKind        TaskKind `json:"TaskKind,omitempty"`
	TaskType        TaskType `json:"TaskType,omitempty"`
	ConcurrentLimit int64    `json:"ConcurrentLimit,omitempty"`
	Urls            string   `json:"Urls,omitempty"`
	HTTPUrlSource   string   `json:"HTTPUrlSource,omitempty"`
}

// See https://www.volcengine.com/docs/6349/128981.
type TosEvents struct {
	Events []TosEvent `json:"events"`
}

type TosEvent struct {
	EventName    string `json:"eventName"`
	EventSource  string `json:"eventSource"`
	EventTime    string `json:"eventTime"`
	EventVersion string `json:"eventVersion"`

	Tos Tos `json:"tos"`
}

type Tos struct {
	TosSchemaVersion string `json:"tosSchemaVersion"`
	RuleId           string `json:"ruleId"`
	Region           string `json:"region"`

	Bucket       Bucket       `json:"bucket,omitempty"`
	Object       Object       `json:"object,omitempty"`
	UserIdentity UserIdentity `json:"userIdentity,omitempty"`
}

type Bucket struct {
	Trn           string `json:"trn,omitempty"`
	Name          string `json:"name,omitempty"`
	OwnerIdentify string `json:"ownerIdentify,omitempty"`
}

type Object struct {
	Etag      string `json:"eTag,omitempty"`
	Key       string `json:"key,omitempty"`
	Size      int64  `json:"size,omitempty"`
	VersionId string `json:"versionId,omitempty"`
}

type RequestParameters struct {
	SourceIPAddress string `json:"sourceIPAddress,omitempty"`
}

type ResponseElements struct {
	TosRequestID string `json:"requestId,omitempty"`
}

type UserIdentity struct {
	PrincipalId string `json:"principalId,omitempty"`
}
