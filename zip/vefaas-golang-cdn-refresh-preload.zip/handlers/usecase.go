package handlers

import (
	"context"
	"io"
	"net/http"
	"strings"
	"time"

	"github.com/volcengine/volc-sdk-golang/service/cdn"
)

func fillUrls(c *ContentTask) error {
	if len(c.Urls) != 0 {
		return nil
	}
	if len(c.HTTPUrlSource) == 0 {
		return badRequest("either Urls or HTTPUrlSource should be specified")
	}
	cli := &http.Client{Timeout: 5 * time.Second}
	r, err := cli.Get(c.HTTPUrlSource)
	if err != nil {
		return svrError("failed to request source url %q, %s", c.HTTPUrlSource, err)
	}
	defer r.Body.Close()
	content, err := io.ReadAll(r.Body)
	if err != nil {
		return svrError("failed to read body from source url %q, %s", c.HTTPUrlSource, err)
	}
	c.Urls = strings.TrimSpace(string(content))
	return nil
}

func doRefresh(ctx context.Context, contentTask *ContentTask) (interface{}, error) {
	var reqID string
	ft := File
	if contentTask.TaskType != "" {
		ft = contentTask.TaskType
	}
	req := &cdn.SubmitRefreshTaskRequest{
		Type: &ft,
		Urls: contentTask.Urls,
	}
	resp, err := cdn.DefaultInstance.SubmitRefreshTask(req)
	if resp.ResponseMetadata != nil {
		reqID = resp.ResponseMetadata.RequestId
	}
	if err != nil {
		return nil, svrError("failed to submit refresh task, error: %s, api_request_id: %s", err, reqID)
	}
	return resp, nil
}

func doPreload(ctx context.Context, contentTask *ContentTask) (interface{}, error) {
	req := &cdn.SubmitPreloadTaskRequest{
		Urls: contentTask.Urls,
	}
	if contentTask.ConcurrentLimit != 0 {
		req.ConcurrentLimit = &contentTask.ConcurrentLimit
	}
	var reqID string
	resp, err := cdn.DefaultInstance.SubmitPreloadTask(req)
	if resp.ResponseMetadata != nil {
		reqID = resp.ResponseMetadata.RequestId
	}
	if err != nil {
		return nil, svrError("failed to submit preload task, error: %s, api_request_id: %s", err, reqID)
	}
	return resp, nil
}

func processTask(ctx context.Context, contentTask *ContentTask) (*BizResp, error) {
	var (
		respData interface{}
		err      error
	)
	err = fillUrls(contentTask)
	if err != nil {
		return nil, err
	}
	switch contentTask.TaskKind {
	case Refresh:
		respData, err = doRefresh(ctx, contentTask)
		if err != nil {
			return nil, err
		}
	case Preload:
		respData, err = doPreload(ctx, contentTask)
		if err != nil {
			return nil, err
		}
	default:
		return nil, badRequest("unrecognized task kind: %s", contentTask.TaskKind)
	}

	return &BizResp{
		Response: respData,
	}, nil
}
