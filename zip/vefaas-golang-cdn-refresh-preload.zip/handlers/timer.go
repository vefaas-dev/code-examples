package handlers

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"os"

	"github.com/volcengine/vefaas-golang-runtime/events"
	"github.com/volcengine/vefaas-golang-runtime/vefaascontext"
)

func handleTimerEvent(ctx context.Context, ce *events.CloudEvent) (*events.EventResponse, error) {
	// Log incoming request.
	//
	// NOTE: the log here is only for debug purpose. It's recommended to delete those debug/info
	// logs and only print log where error occurs after your business logic is verified and ready to
	// go production, nor the log amount may be too huge.
	fmt.Printf(
		"received timer event, request id: %s, extensions: %+v, payload: %s\n",
		vefaascontext.RequestIdFromContext(ctx),
		ce.Extensions(),
		ce.Data(),
	)

	var contentTask ContentTask
	err := json.Unmarshal(ce.Data(), &contentTask)
	if err != nil {
		errMsg := fmt.Sprintf("failed to unmarshal cloudevent payload, error: %v", err)
		fmt.Fprintln(os.Stderr, errMsg)
		return &events.EventResponse{
			StatusCode: http.StatusBadRequest,
			Body:       []byte(errMsg),
		}, nil
	}

	bizResp, err := processTask(ctx, &contentTask)
	return transformResponse(ctx, bizResp, err)
}
