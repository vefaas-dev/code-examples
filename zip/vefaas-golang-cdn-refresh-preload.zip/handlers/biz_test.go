package handlers

import (
	"errors"
	"net/http"
	"testing"
)

func TestBizErrorErrorAs(t *testing.T) {
	foo := badRequest("foobar")
	var be BizError
	if !errors.As(foo, &be) {
		t.Errorf("errors.As, got false, want true")
	}
	if be.Code() != http.StatusBadRequest {
		t.Errorf("be.Code(), got %d, want %d", be.Code(), http.StatusBadRequest)
	}
}
