package handlers

import (
	"fmt"
	"net/http"
)

type BizResp struct {
	RequestID string
	Response  interface{}
}

type BizError interface {
	error
	Code() int
	Reason() string
}

type bizErr struct {
	code   int
	reason string
}

func (b *bizErr) Code() int {
	return b.code
}

func (b *bizErr) Reason() string {
	return b.reason
}

func (b *bizErr) Error() string {
	return fmt.Sprintf("status_code: %d, reason: %s", b.code, b.reason)
}

func badRequest(format string, a ...interface{}) *bizErr {
	return &bizErr{
		code:   http.StatusBadRequest,
		reason: fmt.Sprintf(format, a...),
	}
}

func svrError(format string, a ...interface{}) *bizErr {
	return &bizErr{
		code:   http.StatusInternalServerError,
		reason: fmt.Sprintf(format, a...),
	}
}
