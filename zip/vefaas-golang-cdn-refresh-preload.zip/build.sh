#! /bin/bash
set -ex

cd `dirname $0`

# update dependencies
go get github.com/volcengine/vefaas-golang-runtime
go mod tidy

# build
GOOS=linux GOARCH=amd64 CGO_ENABLED=0 go build -o main
