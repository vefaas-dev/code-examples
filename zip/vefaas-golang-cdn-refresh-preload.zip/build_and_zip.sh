#! /bin/bash
set -ex

cd `dirname $0`

./build.sh

rm -f vefaas-golang-cdn-refresh-preload-trigger.zip
zip -r vefaas-golang-cdn-refresh-preload-trigger.zip . -x '.git*'
