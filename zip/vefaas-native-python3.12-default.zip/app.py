from fastapi import FastAPI

app = FastAPI()

@app.get('/')
def index_handler():
    return 'Hello FastAPI From FaaS nativepython3 (and bye python2)!'

@app.get('/v1/ping')
async def ping_handler():
    return 'Ping healthcheck'

@app.post('/')
async def root_post_handler(payload: dict):
    return {"message": "POST request received", "payload": payload}
