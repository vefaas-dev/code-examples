#! /bin/bash
set -ex

cd `dirname $0`

./build.sh

rm -f vefaas-golang-default.zip
zip -r vefaas-golang-default.zip . -x '.git*'
