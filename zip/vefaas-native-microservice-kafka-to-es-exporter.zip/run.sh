#!/bin/bash

set -ex

./kafka-to-es-exporter
    
