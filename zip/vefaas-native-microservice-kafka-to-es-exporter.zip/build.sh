#!/bin/bash

set -ex

export GOARCH="amd64"
export GOOS="linux"

go build -o ./kafka-to-es-exporter
