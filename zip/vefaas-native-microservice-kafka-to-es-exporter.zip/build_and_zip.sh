#! /bin/bash
set -ex

cd `dirname $0`

./build.sh

zip -FSr vefaas-native-microservice-kafka-to-es-exporter.zip .