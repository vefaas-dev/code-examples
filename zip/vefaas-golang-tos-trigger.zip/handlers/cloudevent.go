package handlers

import (
	"context"
	"errors"
	"fmt"
	"os"

	"github.com/volcengine/vefaas-golang-runtime/events"
	"github.com/volcengine/vefaas-golang-runtime/vefaascontext"
)

func HandleCloudEventRequest(ctx context.Context, ce *events.CloudEvent) (*events.EventResponse, error) {
	switch cloudeventType := ce.Type(); cloudeventType {
	case events.FaasTosEvent:
		return handleTosEvent(ctx, ce)
	default:
		errMsg := fmt.Sprintf("unknown cloudevent type %q, request id: %s, request data: %s",
			cloudeventType,
			vefaascontext.RequestIdFromContext(ctx),
			ce.Data(),
		)
		fmt.Fprintln(os.Stderr, errMsg)
		return nil, errors.New(errMsg)
	}
}
