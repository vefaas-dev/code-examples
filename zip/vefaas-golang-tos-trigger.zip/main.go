package main

import (
	"context"
	"fmt"
	"net/http"
	"os"

	"vefaas-golang-tos-trigger/handlers"

	"github.com/volcengine/vefaas-golang-runtime/events"
	"github.com/volcengine/vefaas-golang-runtime/vefaas"
)

func main() {
	// Start your vefaas function =D.
	vefaas.Start(handler)
}

func handler(ctx context.Context, payload interface{}) (*events.EventResponse, error) {
	switch event := payload.(type) {
	case *events.HTTPRequest:
		return handlers.HandleHttpRequest(ctx, event)
	case *events.CloudEvent:
		return handlers.HandleCloudEventRequest(ctx, event)
	default:
		errMsg := fmt.Sprintf("unknown event type, request: %+v", payload)
		fmt.Fprintln(os.Stderr, errMsg)
		return &events.EventResponse{
			StatusCode: http.StatusBadRequest,
			Body:       []byte(errMsg),
		}, nil
	}
}
