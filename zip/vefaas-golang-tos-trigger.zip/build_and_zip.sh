#! /bin/bash
set -ex

cd `dirname $0`

./build.sh

rm -f vefaas-golang-tos-trigger.zip
zip -r vefaas-golang-tos-trigger.zip . -x '.git*'
