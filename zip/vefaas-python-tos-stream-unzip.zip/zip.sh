#! /bin/bash

set -ex

rm -f vefaas-python-tos-stream-unzip.zip

zip -r vefaas-python-tos-stream-unzip.zip . \
  -x "site-packages/*" \
  -x ".venv/*" \
  -x ".wheels/*" \
  -x "**/.DS_Store" \
  -x "**/__pycache__/*"
