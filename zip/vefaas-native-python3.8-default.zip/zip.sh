#! /bin/bash

set -ex

rm -f vefaas-native-python3.8-default.zip

zip -r vefaas-native-python3.8-default.zip . \
  -x "site-packages/*" \
  -x ".venv/*" \
  -x ".wheels/*" \
  -x "**/.DS_Store" \
  -x "**/__pycache__/*"
