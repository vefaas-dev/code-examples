#! /bin/bash
set -ex

cd `dirname $0`

./build.sh

rm -f vefaas-golang-sns-to-rmq.zip
zip -r vefaas-golang-sns-to-rmq.zip . -x '.git*'
