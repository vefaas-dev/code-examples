package main

import (
	"vefaas-golang-sns-to-rmq/handlers"

	"github.com/volcengine/vefaas-golang-runtime/vefaas"
)

func main() {
	// Start your vefaas function =D.
	vefaas.StartWithInitializer(handlers.Handler, handlers.Initializer)
}
