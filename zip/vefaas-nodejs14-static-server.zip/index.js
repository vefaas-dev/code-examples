const path = require("path");
const fs = require("fs/promises");
const mime = require("mime-types");
const conf = require("./conf.json");

const root = conf.root || "./static";
const index = conf.index || "index.html";
const notfound = conf.notfound || "404.html";
const maxage = conf.maxage || 0;

const toBool = [() => true, () => false];
const isExists = async (path) => await fs.access(path).then(...toBool);

const getFullPath = (pathname) => {
  const paths = [process.cwd(), root, pathname];
  if (!mime.lookup(pathname)) paths.push(index);
  return path.join(...paths);
};

const render404 = async () => {
  const page404 = path.join(process.cwd(), root, notfound);
  const data = await fs.readFile(page404);
  return {
    statusCode: 200,
    headers: { "content-type": "text/html;" },
    body: data,
  };
};

const renderError = (err) => ({
  statusCode: 500,
  headers: { "content-type": "application/json" },
  body: JSON.stringify({ code: 500, message: err }),
});

const useStatic = async (event) => {
  try {
    const fullPath = getFullPath(event.path);
    const exist = await isExists(fullPath);
    const contentType = mime.lookup(path.extname(fullPath));

    if (exist && contentType) {
      const data = await fs.readFile(fullPath);
      return {
        statusCode: 200,
        headers: {
          "content-type": contentType,
          "cache-control": ["public", `max-age=${maxage}`].join(',')
        },
        body: data,
      };
    }
    return await render404();
  } catch (err) {
    console.error(err);
    return renderError(err);
  }
};

exports.handler = async (event, context) => {
  console.log(`received new request, request id: %s`, context.requestId);

  return await useStatic(event);
};
