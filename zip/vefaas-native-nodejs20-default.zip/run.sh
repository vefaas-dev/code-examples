#!/bin/bash
set -ex
cd `dirname $0`

export RUNTIME_LOGDIR=/opt/tiger/toutiao/log

exec node index.js

