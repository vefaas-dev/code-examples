const express = require("express");
const process = require("process");
const fs = require("fs");
const path = require("path");

const content = fs.readFileSync("./static/index.html").toString();

const port = process.env._FAAS_RUNTIME_PORT || 8000;

const app = express();

app.use(express.static(path.resolve(__dirname, "./static")));

app.get("/v1/ping", (req, res) => {
  res.send("ok");
});

app.get("*", (req, res) => {
  res.header("Content-Type", "text/html;charset=utf-8");

  res.send(content);
});

app
  .listen(port, "0.0.0.0", () => {
    console.log("start success.");
  })
  .on("error", (e) => {
    console.error(e.code, e.message);
  });
