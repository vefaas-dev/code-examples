set -ex

export MCP_TRANSPORT=${MCP_TRANSPORT:-streamable-http}
export MCP_SERVER_HOST=${MCP_SERVER_HOST:-0.0.0.0}
export MCP_SERVER_PORT=${MCP_SERVER_PORT:-8000}
export STREAMABLE_HTTP_PATH=${STREAMABLE_HTTP_PATH:-/mcp}

# Run directly from source (no build step)
node src/index.js
