#! /bin/bash

set -ex

rm -f vefaas-native-nodejs20-mcp-server-echo.zip
zip -r vefaas-native-nodejs20-mcp-server-echo.zip . \
  -x "node_modules/*" \
  -x "build/*" \
  -x "package-lock.json" \
  -x "**/.DS_Store"
