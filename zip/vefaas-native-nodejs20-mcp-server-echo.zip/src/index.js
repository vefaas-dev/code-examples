#!/usr/bin/env node
import { createServer } from "node:http";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { SSEServerTransport } from "@modelcontextprotocol/sdk/server/sse.js";
import { z } from "zod";

// Create server instance (Echo)
const server = new McpServer({
  name: "echo",
  version: "0.1.0",
});

// Register tools helper
function registerTools(s) {
  s.tool(
    "hello",
    "Say hello",
    { name: z.string().describe("Name to greet") },
    async ({ name }) => ({ content: [{ type: "text", text: `Hello, ${name}!` }] }),
  );

  s.tool(
    "echo",
    "Echo the input text",
    { text: z.string().describe("Text to echo") },
    async ({ text }) => ({ content: [{ type: "text", text }] }),
  );
}

// Start the server with transport selected by env
async function main() {
  const host = process.env.MCP_SERVER_HOST ?? "0.0.0.0";
  const port = Number(process.env.MCP_SERVER_PORT ?? "8000");
  const path = process.env.STREAMABLE_HTTP_PATH ?? "/mcp";
  const transportPref = (process.env.MCP_TRANSPORT ?? "streamable-http").toLowerCase();

  if (transportPref === "stdio") {
    const stdioTransport = new StdioServerTransport();
    registerTools(server);
    await server.connect(stdioTransport);
    console.error("Echo MCP Server running on stdio");
    // Keep process alive for stdio mode
    setInterval(() => {}, 1 << 30);
    return; // unreachable
  }

  // streamable-http via SDK HTTP transport if available; otherwise fallback to HTTP-over-EventStream
  try {
    // Dynamically import HTTP transport to support varying SDK versions
    let HttpServerTransport;
    let httpModule = await import("@modelcontextprotocol/sdk/server/http.js").catch(() => null);
    HttpServerTransport = httpModule?.HttpServerTransport;
    if (!HttpServerTransport) {
      httpModule = await import("@modelcontextprotocol/sdk/dist/esm/server/http.js").catch(() => null);
      HttpServerTransport = httpModule?.HttpServerTransport;
    }
    if (!HttpServerTransport) {
      httpModule = await import("@modelcontextprotocol/sdk/dist/cjs/server/http.js").catch(() => null);
      HttpServerTransport = httpModule?.HttpServerTransport ?? httpModule?.default?.HttpServerTransport ?? httpModule?.default;
    }
    if (HttpServerTransport) {
      const httpTransport = new HttpServerTransport({ host, port, path });
      registerTools(server);
      await server.connect(httpTransport);
      console.error(`Echo MCP Server (HTTP) listening at http://${host}:${port}${path}`);
      return; // server keeps process alive
    }
    // Fallback: native HTTP server using EventStream for downstream and POST for upstream
    const servers = [];
    const httpServer = createServer(async (req, res) => {
      try {
        const url = new URL(req.url ?? "/", `http://${req.headers.host ?? `${host}:${port}`}`);
        const isStream = req.method === "GET" && url.pathname === path;
        const isMsg = req.method === "POST" && url.pathname === `${path}/message`;

        if (isStream) {
          const transport = new SSEServerTransport(`${path}/message`, res);
          const s = new McpServer({ name: "echo", version: "0.1.0" });
          registerTools(s);
          s.onclose = () => {
            const idx = servers.findIndex((i) => i.transport.sessionId === transport.sessionId);
            if (idx >= 0) servers.splice(idx, 1);
          };
          await s.connect(transport);
          servers.push({ server: s, transport });
          return;
        }

        if (isMsg) {
          const sessionId = url.searchParams.get("sessionId");
          const item = servers.find((i) => i.transport.sessionId === sessionId);
          if (!item) {
            res.writeHead(404).end("Session not found");
            return;
          }
          await item.transport.handlePostMessage(req, res);
          return;
        }

        res.writeHead(404).end("Not Found");
      } catch (err) {
        console.error("HTTP server error:", err);
        try { res.writeHead(500).end("Internal Server Error"); } catch {}
      }
    });

    httpServer.listen(port, host, () => {
      console.error(`Echo MCP Server (HTTP) listening at http://${host}:${port}${path}`);
    });
    return;
  } catch (e) {
    console.error("Failed to start HTTP mode; falling back to stdio:", e);
  }

  // Final fallback: stdio
  const stdioTransport = new StdioServerTransport();
  registerTools(server);
  await server.connect(stdioTransport);
  console.error("Echo MCP Server running on stdio (fallback)");
  setInterval(() => {}, 1 << 30);
}

main().catch((error) => {
  console.error("Fatal error in main():", error);
  process.exit(1);
});
