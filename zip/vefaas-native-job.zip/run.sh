#!/bin/bash
set -Eeuo pipefail

# Change to the directory where the script is located
cd "$(dirname "$0")"

# Log the start time
echo "Script started at $(date)"

# List directory contents
ls

# Simulate a task: Sleeping
echo "Simulating task: Sleeping for 10 seconds"
sleep 10

echo "Script done at $(date)"
