#! /bin/bash
set -Eeuo pipefail

# Change to the directory where the script is located
cd `dirname $0`

# Zip contents
zip -FSr vefaas-native-job.zip .
