The veFaaS function is launched using the Command. No user-side code is required to run the command.

此 veFaaS 函数通过 Command 启动，用户无需编写代码。