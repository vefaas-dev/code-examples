package server

import (
	"fmt"
	"net/http"

	"github.com/alioygur/gores"
)

const (
	requestIdHeaderKey = "X-Faas-Request-Id"
)

// SimpleMessage contains a simple message for return.
type SimpleMessage struct {
	Message string `json:"Message"`
}

func pingHandler(w http.ResponseWriter, _ *http.Request) {
	_ = gores.JSON(w, http.StatusOK, SimpleMessage{Message: "All is well."})
}

func helloHandler(w http.ResponseWriter, r *http.Request) {
	// Log incoming request.
	//
	// NOTE: the log here is only for debug purpose. It's recommended to delete those debug/info
	// logs and only print log where error occurs after your business logic is verified and ready to
	// go production, nor the log amount may be too huge.
	fmt.Printf(
		"received http request: %s %s, request id: %s\n",
		r.Method,
		r.URL.Path,
		r.Header.Get(requestIdHeaderKey),
	)

	_ = gores.JSON(w, http.StatusOK, SimpleMessage{Message: "Hello world from FaaS Native XD"})
}
