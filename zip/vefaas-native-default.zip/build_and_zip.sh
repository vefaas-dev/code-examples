#! /bin/bash
set -ex

cd `dirname $0`

./build.sh

zip -FSr vefaas-native-default.zip .
