#! /bin/bash
set -ex
cd `dirname $0`

go mod tidy

# Note: the binary should be compiled using linux env so as to run on FaaS Platform XD.
GOOS=linux GOARCH=amd64 go build -v -ldflags '-w -extldflags "-static"' -o main
