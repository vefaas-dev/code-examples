package main

import (
	"log"
	"os"
	"os/signal"
	"syscall"

	"vefaas-native-default/server"
)

func main() {
	// Set log flags.
	log.SetFlags(log.Lshortfile | log.Ltime)

	// Start server.
	server := server.NewSimpleServer()
	server.Start()

	// Graceful shutdown.
	stopChan := make(chan os.Signal, 1)
	signal.Notify(stopChan, syscall.SIGTERM, syscall.SIGINT)

	sig := <-stopChan
	log.Printf("received signal %s", sig)
	server.Stop()
}
