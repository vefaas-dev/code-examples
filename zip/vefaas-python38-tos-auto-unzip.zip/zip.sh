#! /bin/bash

set -ex

rm -f vefaas-python38-tos-auto-unzip.zip

zip -r vefaas-python38-tos-auto-unzip.zip . \
  -x "site-packages/*" \
  -x ".venv/*" \
  -x ".wheels/*" \
  -x "**/.DS_Store" \
  -x "**/__pycache__/*"
