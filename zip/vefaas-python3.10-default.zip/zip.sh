#! /bin/bash

set -ex

rm -f vefaas-python3.10-default.zip

zip -r vefaas-python3.10-default.zip . \
  -x "site-packages/*" \
  -x ".venv/*" \
  -x ".wheels/*" \
  -x "**/.DS_Store" \
  -x "**/__pycache__/*"
