#! /bin/bash
set -ex
cd `dirname $0`

gradle build

mkdir -p output/
cp -rf build/* output/
cp run.sh output/
