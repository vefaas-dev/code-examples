#!/bin/bash
set -ex
cd `dirname $0`

# A special check for CLI users (run.sh should be located at the 'root' dir)
if [ -d "output" ]; then
    exec `java -jar output/libs/bytefaas-nativejava8-spring.jar --server.port=$_BYTEFAAS_RUNTIME_PORT`
else
    exec `java -jar libs/bytefaas-nativejava8-spring.jar --server.port=$_BYTEFAAS_RUNTIME_PORT`
fi
