# What
ByteFaaS Native Java8 示例代码

项目采用 SpringBoot 启动，可以正常处理 http/timer/kafka/rocketmq 请求